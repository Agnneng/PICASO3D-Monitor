@echo off
setlocal
cd /d "%~dp0"
echo PICASO3D Monitor - ESP32-C3 flasher
echo Close any serial monitor before continuing.
echo.
set /p "PORT=Enter COM port (for example COM8 or 8): "
if not defined PORT (
  echo No COM port entered.
  pause
  exit /b 1
)
if /i not "%PORT:~0,3%"=="COM" set "PORT=COM%PORT%"
echo.
echo Flashing %PORT% at 460800 baud...
"%~dp0esptool.exe" --chip esp32c3 --port "%PORT%" --baud 460800 --after hard-reset write-flash 0x0 "%~dp0PICASO3D-Monitor-Factory.bin"
if errorlevel 1 goto failed
echo.
echo Flash complete. The device should restart automatically.
echo Saved Wi-Fi and printer settings will be reset; configure the device again.
pause
exit /b 0
:failed
echo.
echo Flash failed. Check the COM port, close other serial tools, and reconnect the board.
echo If the connection is unstable, edit flash.bat and change 460800 to 115200.
pause
exit /b 1
